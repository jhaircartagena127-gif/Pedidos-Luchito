export const PRICE_INICIAL = 240;
export const PRICE_PRIMARIA = 230;

export const products = [
  { id: "prekinder", name: "Prekínder", price: PRICE_INICIAL },
  { id: "kinder", name: "Kínder", price: PRICE_INICIAL },
  { id: "p1", name: "1ro de Primaria", price: PRICE_PRIMARIA },
  { id: "p2", name: "2do de Primaria", price: PRICE_PRIMARIA },
  { id: "p3", name: "3ro de Primaria", price: PRICE_PRIMARIA },
  { id: "p4", name: "4to de Primaria", price: PRICE_PRIMARIA },
  { id: "p5", name: "5to de Primaria", price: PRICE_PRIMARIA },
  { id: "p6", name: "6to de Primaria", price: PRICE_PRIMARIA },
] as const;

export type Qty = Record<string, number>;

export function lineTotals(qty: Qty) {
  return products
    .filter((p) => (qty[p.id] ?? 0) > 0)
    .map((p) => {
      const q = qty[p.id] ?? 0;
      return { ...p, qty: q, subtotal: p.price * q };
    });
}

export function orderTotal(qty: Qty) {
  return lineTotals(qty).reduce((s, l) => s + l.subtotal, 0);
}
