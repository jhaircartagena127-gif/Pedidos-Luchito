import { lineTotals, orderTotal, type Qty } from "@/lib/pricing";

export const BUSINESS_WHATSAPP = "59162185931";

export function whatsappUrl(message: string) {
  return `https://wa.me/${BUSINESS_WHATSAPP}?text=${encodeURIComponent(message)}`;
}

export function orderMessage(customer: { nombre: string; celular: string; unidad: string }, qty: Qty) {
  return [
    "*Nuevo pedido Multitextos Luchito*",
    `Nombre: ${customer.nombre}`,
    `Celular: ${customer.celular}`,
    `Unidad educativa: ${customer.unidad}`,
    "",
    ...lineTotals(qty).map((line) => `• ${line.name}: ${line.qty} x ${line.price} Bs = ${line.subtotal} Bs`),
    "",
    `*TOTAL: ${orderTotal(qty)} Bs*`,
  ].join("\n");
}