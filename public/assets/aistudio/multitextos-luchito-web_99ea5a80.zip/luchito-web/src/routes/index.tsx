import { createFileRoute } from "@tanstack/react-router";
import { BookOpen, Hand, Brain, Palette, Cpu, Music, Heart, MapPin, Phone, Clock, MessageCircle } from "lucide-react";
import logo from "@/assets/clogo.jpg.asset.json";
import pre from "@/assets/c39_1.jpg.asset.json";
import kin from "@/assets/c39.jpg.asset.json";
import p2 from "@/assets/c40.jpg.asset.json";
import p3 from "@/assets/c40_1.jpg.asset.json";
import p4 from "@/assets/c40_2.jpg.asset.json";
import p5 from "@/assets/c41.jpg.asset.json";
import p6 from "@/assets/c41_1.jpg.asset.json";
import p1 from "@/assets/primero-primaria.jpg.asset.json";
import { OrderForm } from "@/components/OrderForm";
import { whatsappUrl } from "@/lib/whatsapp";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Multitextos Luchito | Editorial Luchito Santa Cruz" },
      { name: "description", content: "Multitextos Luchito para Inicial (Prekínder y Kínder) y Primaria de 1ro a 6to. El arte de aprender." },
      { property: "og:title", content: "Multitextos Luchito | Editorial Luchito" },
      { property: "og:description", content: "Textos educativos para Inicial y Primaria: teoría y Manos a la Obra." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const WA = whatsappUrl("Hola, quiero información sobre los multitextos Luchito");

const inicial = [
  { name: "Prekínder", tag: "Inicial I", img: pre.url },
  { name: "Kínder", tag: "Inicial II", img: kin.url },
];
const primaria = [
  { name: "1ro de Primaria", img: p1.url },
  { name: "2do de Primaria", img: p2.url },
  { name: "3ro de Primaria", img: p3.url },
  { name: "4to de Primaria", img: p4.url },
  { name: "5to de Primaria", img: p5.url },
  { name: "6to de Primaria", img: p6.url },
];
const areas = [
  { icon: BookOpen, t: "Comprensión lectora" },
  { icon: Brain, t: "Razonamiento lógico" },
  { icon: Palette, t: "Talleres y arte" },
  { icon: Cpu, t: "Tecnología" },
  { icon: Music, t: "Educación musical" },
  { icon: Heart, t: "Valores y espiritualidad" },
];

function Cover({ img, name }: { img: string | null; name: string }) {
  return img ? (
    <img src={img} alt={`Multitexto ${name}`} loading="lazy" className="aspect-[3/4] w-full object-cover" />
  ) : (
    <div className="flex aspect-[3/4] w-full flex-col items-center justify-center gap-3 bg-hero p-6 text-primary-foreground">
      <span className="font-display text-8xl">1</span>
      <span className="font-display text-xl tracking-wide">PRIMARIA</span>
    </div>
  );
}

function Index() {
  return (
    <div className="font-sans">
      <header className="sticky top-0 z-40 border-b bg-background/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <a href="#" className="flex items-center gap-3">
            <img src={logo.url} alt="Editorial Luchito Santa Cruz" className="h-14 w-14 rounded-full" />
            <span className="font-display text-2xl text-primary">EDITORIAL LUCHITO</span>
          </a>
          <nav className="hidden gap-6 font-bold md:flex">
            <a href="#inicial" className="hover:text-primary">Inicial</a>
            <a href="#primaria" className="hover:text-primary">Primaria</a>
            <a href="#contacto" className="hover:text-primary">Contacto</a>
          </nav>
        </div>
      </header>

      <section className="relative overflow-hidden bg-hero text-primary-foreground">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 md:grid-cols-2 md:py-24">
          <div>
            <p className="mb-3 inline-block rounded-full bg-background px-4 py-1 text-sm font-extrabold text-primary">"El arte de aprender"</p>
            <h1 className="font-display text-5xl leading-tight md:text-6xl">Multitextos Luchito</h1>
            <p className="mt-5 max-w-md text-lg opacity-90">
              Multitextos Luchito para el Nivel Inicial y Primaria.<br />
              {"\u00a0"}Santa Cruz - Boliviana.<br />
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#primaria" className="rounded-full bg-background px-6 py-3 font-extrabold text-primary transition hover:scale-105">Ver productos</a>
              <a href={WA} target="_blank" rel="noreferrer" className="rounded-full border-2 border-primary-foreground px-6 py-3 font-extrabold transition hover:bg-primary-foreground hover:text-primary">Pedir por WhatsApp</a>
            </div>
          </div>
          <div className="relative h-[420px]">
            <img src={p2.url} alt="Multitexto 2do" className="absolute left-0 top-8 w-44 -rotate-6 rounded-xl shadow-2xl md:w-52" />
            <img src={p5.url} alt="Multitexto 5to" className="absolute right-0 top-0 w-44 rotate-6 rounded-xl shadow-2xl md:w-52" />
            <img src={p3.url} alt="Multitexto 3ro" className="absolute bottom-0 left-1/2 w-48 -translate-x-1/2 rounded-xl border-4 border-background shadow-2xl md:w-56" />
          </div>
        </div>
      </section>

      <section id="inicial" className="mx-auto max-w-6xl px-4 py-20">
        <h2 className="font-display text-4xl text-primary">Nivel Inicial</h2>
        <p className="mt-2 text-muted-foreground">Aprendizaje lúdico, práctico y secuencial para el desarrollo integral en Pre-Kínder y Kínder.</p>
        <div className="mt-10 grid gap-8 sm:grid-cols-2">
          {inicial.map((b) => (
            <article key={b.name} className="overflow-hidden rounded-2xl border bg-card shadow-card transition hover:-translate-y-1">
              <img src={b.img} alt={`Multitexto ${b.name}`} loading="lazy" className="aspect-[4/3] w-full object-cover" />
              <div className="flex items-center justify-between p-5">
                <div>
                  <span className="text-sm font-bold text-primary">{b.tag}</span>
                  <h3 className="font-display text-2xl">{b.name}</h3>
                  <p className="font-display text-xl text-primary">240 Bs</p>
                </div>
                <a href="#pedido" className="rounded-full bg-primary px-4 py-2 font-bold text-primary-foreground">Pedir</a>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section id="primaria" className="bg-muted py-20">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="font-display text-4xl text-primary">Primaria · 1ro a 6to</h2>
          <div className="mt-6 grid gap-4 md:grid-cols-2">
            <div className="flex gap-4 rounded-2xl bg-card p-6 shadow-card">
              <BookOpen className="h-10 w-10 shrink-0 text-primary" />
              <div><h3 className="text-xl font-extrabold">Multitextos Luchitos</h3><p className="text-muted-foreground">Cuatros áreas fundamentales integradas para el desarrollo integral del nivel primario.</p></div>
            </div>
            <div className="flex gap-4 rounded-2xl bg-card p-6 shadow-card">
              <Hand className="h-10 w-10 shrink-0 text-primary" />
              <div><h3 className="text-xl font-extrabold">Manos a la Obra</h3><p className="text-muted-foreground">Entorno practico para la consolidación del saber mediante la acción, la música y los valores comunitario.</p></div>
            </div>
          </div>
          <div className="mt-6 flex flex-wrap gap-3">
            {areas.map(({ icon: I, t }) => (
              <span key={t} className="flex items-center gap-2 rounded-full border-2 border-primary bg-background px-4 py-2 font-bold text-primary">
                <I className="h-4 w-4" /> {t}
              </span>
            ))}
          </div>
          <div className="mt-12 grid grid-cols-2 gap-6 md:grid-cols-3">
            {primaria.map((b) => (
              <article key={b.name} className="overflow-hidden rounded-2xl bg-card shadow-card transition hover:-translate-y-1">
                <Cover img={b.img} name={b.name} />
                <div className="p-4">
                  <h3 className="font-extrabold">{b.name}</h3>
                  <p className="font-display text-xl text-primary">230 Bs</p>
                  <a href="#pedido" className="mt-2 inline-block text-sm font-bold text-primary">Pedir →</a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="pedido" className="mx-auto max-w-6xl px-4 py-20">
        <h2 className="font-display text-4xl text-primary">Haz tu pedido</h2>
        <p className="mt-2 mb-8 text-muted-foreground">Llena tus datos, elige tus productos y verás el total al instante.</p>
        <OrderForm />
      </section>

      <footer id="contacto" className="bg-brand-dark text-primary-foreground">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 md:grid-cols-3">
          <div className="flex items-center gap-4">
            <img src={logo.url} alt="Logo Luchito" className="h-20 w-20 rounded-full" />
            <div><p className="font-display text-2xl">LUCHITO</p><p className="opacity-80">Editorial · Santa Cruz</p></div>
          </div>
          <div className="space-y-3">
            <p className="flex gap-3"><MapPin className="h-5 w-5" /> Calle Germán Herraes 125</p>
            <p className="flex gap-3"><Phone className="h-5 w-5" /> <a href="tel:+59162185931">+591 62185931</a></p>
          </div>
          <div className="flex gap-3">
            <Clock className="h-5 w-5 shrink-0" />
            <div><p className="font-bold">Horario de atención</p><p>07:00 – 12:30</p><p>14:00 – 18:30</p></div>
          </div>
        </div>
        <p className="border-t border-primary-foreground/20 py-4 text-center text-sm opacity-70">© {new Date().getFullYear()} Editorial Luchito</p>
      </footer>

      <a href={WA} target="_blank" rel="noreferrer" aria-label="WhatsApp" className="fixed bottom-6 right-6 z-50 flex h-16 w-16 items-center justify-center rounded-full bg-whatsapp text-primary-foreground shadow-2xl transition hover:scale-110">
        <MessageCircle className="h-8 w-8" />
      </a>
    </div>
  );
}
