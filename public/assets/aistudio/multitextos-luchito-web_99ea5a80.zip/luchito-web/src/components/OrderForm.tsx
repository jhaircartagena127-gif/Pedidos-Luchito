import { useState } from "react";
import { z } from "zod";
import { products, lineTotals, orderTotal, type Qty } from "@/lib/pricing";
import { Button } from "@/components/ui/button";
import { orderMessage, whatsappUrl } from "@/lib/whatsapp";

const schema = z.object({
  nombre: z.string().trim().min(2, "Escribe tu nombre").max(100),
  celular: z.string().trim().regex(/^[0-9+ ]{7,15}$/, "Número de celular no válido"),
  unidad: z.string().trim().min(2, "Escribe la unidad educativa").max(150),
});

export function OrderForm() {
  const [f, setF] = useState({ nombre: "", celular: "", unidad: "" });
  const [qty, setQty] = useState<Qty>({});
  const [err, setErr] = useState("");
  const [preparedUrl, setPreparedUrl] = useState("");
  const lines = lineTotals(qty);
  const total = orderTotal(qty);

  const handleChange = () => {
    setPreparedUrl("");
    setErr("");
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const r = schema.safeParse(f);
    if (!r.success) return setErr(r.error.issues[0]?.message ?? "Revisa tus datos");
    if (!lines.length) return setErr("Selecciona al menos un producto");
    setErr("");
    setPreparedUrl(whatsappUrl(orderMessage(r.data, qty)));
  };

  const input = "w-full rounded-xl border-2 bg-background px-4 py-3 focus:border-primary focus:outline-none";

  return (
    <form onSubmit={submit} onChange={handleChange} className="grid gap-8 rounded-2xl bg-card p-6 shadow-card md:grid-cols-2 md:p-10">
      <div className="space-y-4">
        <h3 className="font-display text-2xl">Tus datos</h3>
        <input className={input} placeholder="Nombre completo" maxLength={100} value={f.nombre} onChange={(e) => setF({ ...f, nombre: e.target.value })} />
        <input className={input} placeholder="Número de celular" inputMode="tel" maxLength={15} value={f.celular} onChange={(e) => setF({ ...f, celular: e.target.value })} />
        <input className={input} placeholder="Unidad educativa" maxLength={150} value={f.unidad} onChange={(e) => setF({ ...f, unidad: e.target.value })} />
      </div>
      <div>
        <h3 className="font-display text-2xl">Productos</h3>
        <ul className="mt-4 divide-y">
          {products.map((p) => (
            <li key={p.id} className="flex items-center justify-between gap-3 py-2">
              <div><p className="font-bold">{p.name}</p><p className="text-sm text-muted-foreground">{p.price} Bs c/u</p></div>
              <input
                type="number" min={0} max={999} aria-label={`Cantidad ${p.name}`}
                value={qty[p.id] ?? 0}
                onChange={(e) => setQty({ ...qty, [p.id]: Math.max(0, Math.min(999, Math.floor(Number(e.target.value) || 0))) })}
                className="w-20 rounded-lg border-2 px-2 py-1 text-center focus:border-primary focus:outline-none"
              />
            </li>
          ))}
        </ul>
      </div>
      <div className="md:col-span-2">
        {lines.length > 0 && (
          <div className="rounded-xl bg-muted p-4">
            {lines.map((l) => (
              <p key={l.id} className="flex justify-between"><span>{l.name} ({l.qty} x {l.price} Bs)</span><b>{l.subtotal} Bs</b></p>
            ))}
            <p className="mt-2 flex justify-between border-t pt-2 font-display text-xl text-primary"><span>Total</span><span>{total} Bs</span></p>
          </div>
        )}
        {err && <p role="alert" className="mt-3 font-bold text-destructive">{err}</p>}
        {preparedUrl ? (
          <div className="mt-4 space-y-3">
            <p role="status" className="font-bold">Pedido preparado · WhatsApp +591 62185931</p>
            <Button asChild className="h-auto w-full whitespace-normal rounded-full px-6 py-4 font-extrabold">
              <a href={preparedUrl} target="_blank" rel="noopener noreferrer">Abrir WhatsApp y enviar pedido</a>
            </Button>
          </div>
        ) : (
          <Button type="submit" className="mt-4 h-auto w-full whitespace-normal rounded-full px-6 py-4 font-extrabold">
            Enviar pedido por WhatsApp
          </Button>
        )}
      </div>
    </form>
  );
}
