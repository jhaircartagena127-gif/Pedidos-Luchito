import { describe, it, expect } from "vitest";
import { lineTotals, orderTotal } from "@/lib/pricing";

describe("precios", () => {
  it("prekinder y kinder cuestan 240 Bs", () => {
    expect(orderTotal({ prekinder: 1 })).toBe(240);
    expect(orderTotal({ kinder: 1 })).toBe(240);
  });
  it("cada libro de primaria cuesta 230 Bs", () => {
    for (const id of ["p1", "p2", "p3", "p4", "p5", "p6"]) expect(orderTotal({ [id]: 1 })).toBe(230);
  });
  it("subtotal por producto separado", () => {
    const l = lineTotals({ kinder: 2, p3: 3 });
    expect(l.map((x) => x.subtotal)).toEqual([480, 690]);
    expect(orderTotal({ kinder: 2, p3: 3 })).toBe(1170);
  });
});
