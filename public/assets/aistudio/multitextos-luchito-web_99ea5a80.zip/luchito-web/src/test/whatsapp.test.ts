import { describe, expect, it } from "vitest";
import { orderMessage, whatsappUrl } from "@/lib/whatsapp";

describe("WhatsApp orders", () => {
  it("addresses the business number, not the customer's phone", () => {
    const url = new URL(whatsappUrl("Pedido"));
    expect(url.origin).toBe("https://wa.me");
    expect(url.pathname).toBe("/59162185931");
  });

  it("preserves customer data, quantities and separate amounts", () => {
    const message = orderMessage(
      { nombre: "María Pérez", celular: "70000000", unidad: "Escuela & Colegio" },
      { prekinder: 2, p3: 3 },
    );
    expect(message).toContain("Nombre: María Pérez\nCelular: 70000000\nUnidad educativa: Escuela & Colegio");
    expect(message).toContain("Prekínder: 2 x 240 Bs = 480 Bs");
    expect(message).toContain("3ro de Primaria: 3 x 230 Bs = 690 Bs");
    expect(message).toContain("*TOTAL: 1170 Bs*");
    expect(new URL(whatsappUrl(message)).searchParams.get("text")).toBe(message);
  });
});